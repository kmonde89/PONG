#version 150


in vec4 primaryColor;
out vec4 fragColor;
void main() {
	fragColor = primaryColor;
}